# Hats & Shoes > 2025-01-03 8:31pm
https://universe.roboflow.com/mao-workspace/hats-shoes

Provided by a Roboflow user
License: CC BY 4.0

