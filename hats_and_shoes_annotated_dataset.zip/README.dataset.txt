# Hats & Shoes > 2025-01-01 4:25pm
https://universe.roboflow.com/mao-workspace/hats-shoes

Provided by a Roboflow user
License: CC BY 4.0

